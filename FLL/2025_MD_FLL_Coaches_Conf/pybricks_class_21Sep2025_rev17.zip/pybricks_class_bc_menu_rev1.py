# Pybricks Class Menu
# menu revision number
menu_revision="1"
#
# import our library
from pybricks.tools import hub_menu, wait
print("Block Coding Robot Menu, rev#",menu_revision)

# Make a menu to choose a letter. You can also use numbers.
while True:
    selected = hub_menu("M", "1", "2","3","X")
    try:
        if selected == "M":
            # does nothing. used to show menu is active
            break
        if selected == "1":
            wait(1000)
            import pybricks_class_bc_task1_rev1
        elif selected == "2":
            wait(1000)
            import pybricks_class_bc_task2_rev2
        elif selected == "3":
            wait(1000)
            import pybricks_class_bc_task3_rev1
        elif selected == "X":
            # does nothing used to show end of menu
            break
    except BaseException as menuException:
        print("Stop was Pressed or a Critical Error Occurred.")
        print(menuException)
        break