# Pybricks Class Task 3
import  pybricks_class_library_rev4 as RobotLib

async def pybricks_class_task3():
    # Pybricks Class Block Coding Task3
    print("Running Pybricks Class Task 3")

    await RobotLib.initializeRobotForTask() 
    
    distance_to_move = 400
    RobotLib.driveBase.settings(straight_speed=200, straight_acceleration=600)
    print('Drive Forward by', distance_to_move, 'mm')
    await RobotLib.driveBase.straight(distance_to_move, then=RobotLib.Stop.BRAKE)
    distance_to_move = -350
    print('Drive Backward by', distance_to_move, 'mm')
    await RobotLib.driveBase.straight(distance_to_move, then=RobotLib.Stop.BRAKE)
    print('Stop and move attachment')
    RobotLib.rightAttachment.control.limits(speed=950,acceleration=950)
    print('Stop Robot')
    RobotLib.driveBase.use_gyro(False)

#run_task(pybricks_class_task3())
