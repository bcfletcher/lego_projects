# Robot Lib Demonstration
#
# task revision number
t1_revision="2"
#
import pybricks_class_library_rev4 as RobotLib

async def pybricks_class_task4(): 
    print ("Robot Library Demonstration, Suibmerged Demo rev=",t1_revision)
    await RobotLib.initializeRobotForTask()

    await RobotLib.wait(1000)
    if RobotLib.debugL1: print(" get and place coral tree")
    await RobotLib.driveRobot(285,750,500)
    await RobotLib.driveRobotAndLift(160,100,100,"left",1750,1000,"hold",False,True)
    await RobotLib.turnRobot(5,100,100)
    await RobotLib.driveRobotAndLift(-230,300,150,"left",1100,1000,"hold",False,True)
    await RobotLib.turnRobotAndLift(25,200,100,"left",1850,1000,"hold",False,True)

    if RobotLib.debugL1: print(" smash coral nursery")
    await RobotLib.driveRobot(580,850,500)
    await RobotLib.turnRobot(-15,200,200)
    await RobotLib.moveAttachment("right",-200,1000,"hold",False,True)
    await RobotLib.moveAttachment("right",0,1000,"hold",False,True)
    await RobotLib.driveRobot(-105,400,100)
    await RobotLib.turnRobot(76,200,200)

    if RobotLib.debugL1: print(" lift mast")
    await RobotLib.driveRobotAndLift(-80,100,100,"right",-170,300,"hold",False,True)
    # drive slowly to light mast
    await RobotLib.turnRobot(5,100,100)
    await RobotLib.driveRobot(260,200,400)
    # drive away from ship and lift robot arm out of the way
    await RobotLib.driveRobot(-210,400,1000)
    await RobotLib.moveAttachment("right",0,100,"hold",False,True)
    await RobotLib.driveRobot(100,400,1000)

    if RobotLib.debugL1: print(" goto shark")
    await RobotLib.turnRobot(-142,200,200)
    await RobotLib.driveRobot(300,700,500)

    if RobotLib.debugL1: print(" move away from shark")
    await RobotLib.driveRobot(-75,500,100)

    if RobotLib.debugL1: print(" pickup scuba diver")
    await RobotLib.turnRobot(-34,100,100)

    if RobotLib.debugL1: print(" pickup scuba diver")
    await RobotLib.driveRobot(-20,600,500)
    await RobotLib.driveRobotAndLift(80,100,100,"left",1100,950,"hold",False,True)
    await RobotLib.moveAttachment("left",1850,900,"hold",False,True)
    await RobotLib.driveRobot(-70,600,500)
    await RobotLib.turnRobot(45,300,300)
    await RobotLib.driveRobot(-175,500,500)

    if RobotLib.debugL1: print("   turn to coral reef to drop off diver")
    await RobotLib.turnRobot(70,300,100)
    await RobotLib.driveRobotAndLift(-45,400,400,"left",1450,900,"hold",False,True)
    await RobotLib.driveRobot(210,500,500)
    await RobotLib.turnRobot(-12,100,100)
    # left attachment for seabed
    #await driveRobotAndLift(-140,100,100,"left",850,900,False,True,continuePrompt)
    # right attachment for seabed
    await RobotLib.driveRobotAndLift(-140,100,100,"left",300,950,"hold",False,True,)

    await RobotLib.stopEverything()
    print("Task 1 - Completed")
