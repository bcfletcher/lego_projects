# Basic FLL Robot Library
#
# This code is released under the Apache License v2.0
# https://www.apache.org/licenses/LICENSE-2.0.txt
#
#
# Developed against Pybricks 3.6.1 
#
# This code should work with any Lego Spike Prime/Robot Inventor robot with two motors for attachments
# 
#
# Update this if you change the code
coreLib_revision="4"
coreLib_date="14 September 2025"
#
#
from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Axis, Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.iodevices import XboxController
from pybricks.tools import wait, StopWatch, multitask, run_task, hub_menu
from umath import sin, pi
from pybricks.hubs import PrimeHub

#
# change this for your configuration file
#

# define and set the debug levels
debugL1=True
debugL2=False

#
# create some globals used by robot library functions
#
'''
attachmentsPresent=True
leftAttachment=True
leftAttachmentName="left"
rightAttachment=True
rightAttachmentName="right"
driveBase=None
leftMotor=None
rightMotor=None
hub=None
LeftDriveMotorPort=None
LeftAttachmentMotorPort=None
RightDriveMotorPort=None
RightAttachmentMotorPort=None
leftAttachmentHasGears=False
rightAttachmentHasGears=False
'''

def initiatizeRobot():

    global hub
    global leftAttachment
    global leftAttachmentName
    global rightAttachment
    global rightAttachmentName
    global attachmentsPresent
    global driveBase
    global leftMotor
    global rightMotor
    global leftDriveMotorPort
    global rightDriveMotorPort
    global leftAttachmentMotorPort
    global rightAttachmentMotorPort    
    global leftAttachmentHasGears
    global rightAttachmentHasGears

    # initialize the robot's
    hub = PrimeHub()


    # print some information about the robot library
    if debugL1: print("Basic Robot Library Rev#",coreLib_revision,"Release Date: ",coreLib_date)
    if debugL1: print("   Initializing Robot")
    if debugL1: print("   Using hub named: ", hub.system.name())

    # set the hub LED display to the correct orientation
    hub.display.orientation(Side.RIGHT)   #Side.TOP is the "normal" hub position
    # set this to true if there are attachments
    attachmentsPresent=True

    # the port locations for the light sensors, drive motors, and attachment motors
    LeftDriveMotorPort=Port.B
    RightDriveMotorPort=Port.A
    RightAttachmentMotorPort=Port.C
    LeftAttachmentMotorPort=Port.D

    # Initialize  motors and sensors. The motor on the
    # left must turn counterclockwise to make the robot go forward.
    if debugL2: print("DEBUG-L2 - Assigning & Configuring Motors")
    leftMotor = Motor(LeftDriveMotorPort, Direction.COUNTERCLOCKWISE,reset_angle=True)
    rightMotor = Motor(RightDriveMotorPort,Direction.CLOCKWISE,reset_angle=True)

    #
    # setup drive base and default performance parameters
    #
    # IMPORTANT: wheelDiameter & axleTrack are specific for your robot!! 
    # both values are in millimeters (mm)
    # axleTrack is the measurement between the centerpoints of the both wheel treads
    # the axleTrack & wheelDiameter likely will need to tweaking. read the Pybricks doc on DriveBase
    # in the subsection "Measuring and validating the robot dimensions" on howtune these settings
    #
    if debugL2: print("DEBUG-L2 - Configuring the DriveBase")
    wheelDiameter=62.4
    axleTrack=204
    driveBase = DriveBase(leftMotor,rightMotor, 
                            wheel_diameter=wheelDiameter,
                            axle_track=axleTrack) 
    #
    # set some default motor settings for your drive motors
    # 
    DefaultStraightSpeed=400
    DefaultStraightAcceleration=[500,500]
    DefaultTurnAcceleration=[500,500]
    DefaultTurnRate=300
    if debugL2: print("DEBUG-L2 - Configuring the Speed & Acceleration default settings")

    driveBase.settings(straight_speed=DefaultStraightSpeed,
                        straight_acceleration=DefaultStraightAcceleration,
                        turn_acceleration=DefaultTurnAcceleration,
                        turn_rate=DefaultTurnRate)
    #
    # configured motors for the two attachments
    #
    if attachmentsPresent == True: 
        if debugL2: print("DEBUG-L2 - Configuring Attachment Motors")
        leftAttachment = Motor(LeftAttachmentMotorPort,Direction.CLOCKWISE,reset_angle=True)
        rightAttachment = Motor(RightAttachmentMotorPort,Direction.CLOCKWISE,reset_angle=True)

# clear the console
def clearConsole():
    print("\x1b[H\x1b[3J", end="")
    print("\x1b[H\x1b[2J", end="")

# Display Robot statistics
async def displayRobotStats(resetStats):
    print("*************************************")
    print("* Robot Stats:")
    if attachmentsPresent == True:
        if leftRightAttachments == True:
            print("* Attachments Present: Left/Right Mode")
        else:
            print("* Attachments Present: Top/Front Mode") 
    print("* Distance Driven (est)=",driveBase.distance())
    print("* Rotation Angle (est)=",driveBase.angle())
    print("* Hub Ready=",hub.imu.ready()," Stationary=",hub.imu.stationary())
    print("* Hub Up=",hub.imu.up())
    if resetStats:
        driveBase.reset()
    print("*************************************")

# initialize the robot for a task. basically resets the
# attachments, enables the gyro, and makes sure the robot
# is calibrated
async def initializeRobotForTask():
    if debugL1: print("   Initializing Robot for Task")
    
    # calibrate robot
    while hub.imu.ready() != True:
        await wait(250)
        
    # generally you should reset the motors to zero
    if attachmentsPresent: 
        await resetAttachment("left")
        await resetAttachment("right")

    driveBase.use_gyro(False)
    driveBase.reset(angle=0,distance=0)
    hub.imu.reset_heading(0)
    driveBase.use_gyro(True)

    if debugL1: print("   Completed Robot Initialization")

# used to reset and attachment to a new "zero" position
async def resetAttachment(attachmentStr):
    if attachmentsPresent == False: return
    if attachmentStr == "left":
        attachment=leftAttachment
    elif attachmentStr == "right":
        attachment=rightAttachment
    else:
        print("resetAttachment() - illegal attachment name of ",attachmentStr)
        return False
    
    if debugL2: print("DEBUG-L2 - Start resetAttachment() attachment=",attachmentStr," previous angle=",attachment.angle())
    attachment.reset_angle(0)
    if debugL2: print("DEBUG-L2 - End resetAttachment() attachment=",attachmentStr," new angle=",attachment.angle())


# detect if a specific attachment is stalled, used with multitask() in moveAttachment functions
async def isStalled(attachment) -> bool :

    if debugL2: print("isStalled()",attachment.stalled())

    while attachment.stalled() == False: 
        await wait(1)

    if debugL1: print("stalled")

    return attachment.stalled()

# move attachment with stall detection and specific stop modes
async def moveAttachment(attachmentStr,degrees,speed,stopMode,resetAngle,stallDetect) -> bool:

    # assign to attachment the actual correct value for the attachment
    if attachmentStr == "left":
        attachment=leftAttachment
    elif attachmentStr == "right":
        attachment=rightAttachment
    else:
        print("moveAttachment() - ERROR, illegal attachment name of ",attachmentStr)
        return False

    if debugL2: print("DEBUG-L2 - Start moveAttachment() attachment=",attachmentStr," angle=",attachment.angle()," new angle=",degrees," speed=", speed, " stop mode=",stopMode," wait=",waitMode," stallDetect=",stallDetect)

    if resetAngle == True: resetAttachment(attachmentStr)

    #
    # Motors have different stop modes. HOLD is used 
    # for picking up and carrying items. Hold or Brake
    # is good for lifting a lever or object that the 
    # robot doesn't have to carry. Coast is best for
    # levers you have to push down.
    #
    if stopMode == "hold": 
        stopMode=Stop.HOLD
    elif stopMode == "brake":
        stopMode=Stop.BRAKE
    elif stopMode == "coast":
        stopMode=Stop.COAST 
    else:
        stopMode=Stop.HOLD

    if (stallDetect == True):
           # move the attachment a specific number of degree 
           # WHILE also checking to see  if the motor has 
           # stalled using the isStalled() function when race=True
           # it will run both command until one finishes then it 
           # kills the other one. so if the motor stalls it will 
           # kill the run_target() function
           await multitask(attachment.run_target(speed,degrees,then=Stop.HOLD),isStalled(attachment),race=True)

    else:
        await attachment.run_target(speed,degrees,then=stopMode,wait=True)
    
    if debugL2: print("DEBUG-L2 - End moveAttachmentFC() final angle=",topAttachment.angle())

    return True

# drive robot forward or backward (-negative dist)
async def driveRobot(dist,speed, accel) -> bool :

    if debugL2: print("DEBUG-L2 - driveRobot() dist=",dist," speed=",speed," accel=",accel)

    # configure the speed and accelerationn values
    driveBase.settings(straight_speed=speed,
                       straight_acceleration=accel)
    await driveBase.straight(dist,then=Stop.HOLD,wait=True)
    if debugL2: print("DEBUG-L2 - driveRobot() done dist travelled=",driveBase.distance())
    return True

# turn robot forward or backward (use negative number for
# backward if robot facing forwards). if robot is facing 
# backwards, forward is then the negative number
async def turnRobot(dir,turnAccel, turnRate) -> bool :

    if debugL2: print("DEBUG-L2 - turnRobot() dir=",dir," turnAccel=",turnAccel," turnRate=",turnRate)
    driveBase.settings(turn_acceleration=turnAccel,
                       turn_rate=turnRate)
    await driveBase.turn(dir,then=Stop.HOLD,wait=True)
    if debugL2: print("DEBUG-L2 - turnRobot() done")
    return True

#
# drive robot in arc
#
async def driveRobotInArc(radius,mode,angleOrDist,speed,accel,turnAccel,turnRate) -> bool :

    await promptToContinue(waitForPrompt)
    driveBase.settings(straight_speed=speed,
                    straight_acceleration=accel,
                    turn_acceleration=turnAccel,
                    turn_rate=turnRate)
    if mode == "angle": 
        if debugL2: print("DEBUG-L2 - turnRobotInArc() radius=",radius," mode=arc degrees=",angleOrDist)
        await driveBase.arc(radius,angle=angleOrDist,then=Stop.HOLD,wait=True)

    if mode == "distance": 
        if debugL2: print("DEBUG-L2 - turnRobotInArc() radius=",radius," mode=distance distance=",angleOrDist)
        await driveBase.arc(radius,distance=angleOrDist,then=Stop.HOLD,wait=True)

    if debugL2: print("DEBUG-L2 - turnRobotInArc() done")
    return True

# drive robot in an arc while moving attachment
async def driveRobotInArcAndLift(radius,mode,angleOrDist,attachmentStr,degrees,aSpeed,stopMode,resetAngle,stallDetect) -> bool:

    # assign to attachment the actual correct value for the attachment
    if attachmentStr == "left":
        attachment=leftAttachment
    elif attachmentStr == "right":
        attachment=rightAttachment
    else:
        print("driveRobotInArcAndLift() - illegal attachment name of ",attachmentStr)
        return False

    # 
    #  pybricks arc distance movemewnt can be described in terms of degrees or distance in mm
    #                        
    if mode == "angle": 
        if debugL2: print("DEBUG-L2 - driveRobotInArcAndLift() radius=",radius," mode=arc degrees=",angleOrDist,
                          " attach=",attachmentStr," degrees=",degrees," aSpeed=",aSpeed," resetAngle=",resetAngle," stallDetect=",stallDetect)
        await multitask(driveBase.arc(radius,angle=angleOrDist,then=Stop.HOLD,wait=True),
                        moveAttachment(attachmentStr,degrees,aSpeed,stopMode,resetAngle,stallDetect))

    if mode == "distance": 
        if debugL2: print("DEBUG-L2 - driveRobotInArcAndLift() radius=",radius," mode=distance distance=",angleOrDist,
                          " attach=",attachmentStr," degrees=",degrees," aSpeed=",aSpeed," resetAngle=",resetAngle," stallDetect=",stallDetect)
        await multitask(driveBase.arc(radius,distance=angleOrDist,then=Stop.HOLD,wait=True),
                        moveAttachment(attachmentStr,degrees,aSpeed,stopMode,resetAngle,stallDetect)) 
    
    if debugL2: print("DEBUG-L2 - driveRobotInArcAndLift() done")
    return True


# drive robot forward or backward  while moving attachment
async def driveRobotAndLift(dist,dSpeed,accel,attachmentStr,degrees,aSpeed,stopMode,resetAngle,stallDetect) -> bool: 

    # assign to attachment the actual correct value for the attachment
    if attachmentStr == "left":
        attachment=leftAttachment
    elif attachmentStr == "right":
        attachment=rightAttachment
    else:
        print("driveRobotAndLift() - illegal attachment name of ",attachmentStr)
        return False
        
    if debugL2: print("DEBUG-L2 - driveRobotAndLift() dist=",dist," dSpeed=",dSpeed," accel=",accel," attach=",attachmentStr," degrees=",
                        degrees," aSpeed=",aSpeed," resetAngle=",resetAngle," stallDetect=",stallDetect)
    await multitask(driveRobot(dist,dSpeed,accel),
                    moveAttachment(attachmentStr,degrees,aSpeed,stopMode,resetAngle,stallDetect))
    if debugL2: print("DEBUG-L2 - driveRobotAndLift() done")
    return True

# turn robot while moving attachment
async def turnRobotAndLift(dir,turnAccel, turnRate,attachmentStr,degrees,aSpeed,stopMode,resetAngle,stallDetect) -> bool:

    if attachmentStr == "left":
        attachment=leftAttachment
    elif attachmentStr == "right":
        attachment=rightAttachment
    else:
        print("turnRobotAndLift() - illegal attachment name of ",attachmentStr)
        return False
        
    if debugL2: print("DEBUG-L2 - turnRobotAndLift() dir=",dir," turnAccel=",turnAccel," turnRate=",turnRate," attach=",attachmentStr," degrees=",
                        degrees," aSpeed=",aSpeed," resetAngle=",resetAngle," stallDetect=",stallDetect)
    await multitask(turnRobot(dir,turnAccel, turnRate),
                    moveAttachment(attachmentStr,degrees,aSpeed,stopMode,resetAngle,stallDetect))
    if debugL2: print("DEBUG-L2 - turnRobotAndLift() done")
    return True

# stops the motors and disables the gyroscope (if 
# you lift it off the table) this should be run at
# the end of every task in the task and in menu
# after each task
async def stopEverything():
    if debugL1: print("Stop All Motors & Gyro")
    driveBase.use_gyro(False)
    await wait(100)
    leftMotor.stop()
    await wait(100)
    rightMotor.stop()
    await wait(100)
    if attachmentsPresent: 
        leftAttachment.stop()
        rightAttachment.stop()
    await wait(100)
    if debugL1: print("All motors should be stopped")



#
# End
#