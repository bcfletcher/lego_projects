from pybricks.hubs import PrimeHub
from pybricks.iodevices import XboxController
from pybricks.parameters import Button, Direction, Port, Stop
from pybricks.pupdevices import Motor
from pybricks.robotics import DriveBase
from pybricks.tools import wait

# Set up all devices.
prime_hub = PrimeHub()
right_motor = Motor(Port.A, Direction.CLOCKWISE)
left_motor = Motor(Port.B, Direction.COUNTERCLOCKWISE)
attachment_motor = Motor(Port.C, Direction.CLOCKWISE)
drive_base = DriveBase(left_motor, right_motor, 62.4, 204)
controller = XboxController()

# Initialize variables.
mySpeed = 950

def xbox_controller_test():
    global mySpeed
    print('Connected')
    drive_base.use_gyro(False)
    drive_base.reset(0, 0)
    drive_base.settings(straight_speed=mySpeed)
    drive_base.settings(straight_acceleration=750)
    while not Button.X in controller.buttons.pressed():
        if Button.UP in controller.buttons.pressed():
            print('forward')
            drive_base.straight(10, then=Stop.NONE)
            wait(100)
        elif Button.DOWN in controller.buttons.pressed():
            print('backward')
            drive_base.straight(-10, then=Stop.NONE)
            wait(100)
        elif Button.LEFT in controller.buttons.pressed():
            print('left', drive_base.angle())
            drive_base.turn(-1, then=Stop.NONE)
            wait(10)
        elif Button.RIGHT in controller.buttons.pressed():
            print('right', drive_base.angle())
            drive_base.turn(1, then=Stop.NONE)
            wait(10)
        elif Button.A in controller.buttons.pressed():
            drive_base.stop()
            wait(100)
        elif Button.B in controller.buttons.pressed():
            print('B_dist=', drive_base.distance())
            wait(100)
        elif Button.Y in controller.buttons.pressed():
            print('Y_angle=', drive_base.angle(), ' hub_heading=', prime_hub.imu.heading())
            wait(100)
        elif Button.RB in controller.buttons.pressed():
            attachment_motor.run_angle(900, -190, Stop.COAST)
            wait(100)
        elif Button.LB in controller.buttons.pressed():
            attachment_motor.run_angle(900, 190, Stop.COAST)
            wait(100)
        elif Button.MENU in controller.buttons.pressed():
            print('Dist/Angle Reset')
            drive_base.reset(0, 0)
            prime_hub.imu.reset_heading(0)
            drive_base.settings(straight_speed=10)
            mySpeed = 10
            wait(100)
        elif Button.VIEW in controller.buttons.pressed():
            mySpeed = mySpeed + 10
            print('Up Speed=', mySpeed)
            if mySpeed > 960:
                mySpeed = 950
            drive_base.settings(straight_speed=mySpeed)
            wait(100)
        elif Button.UPLOAD in controller.buttons.pressed():
            mySpeed = mySpeed - 10
            print('Down Speed=', mySpeed)
            if mySpeed <= 10:
                mySpeed = 10
            drive_base.settings(straight_speed=mySpeed)
            wait(100)
        else:
            wait(100)
    print('Program Ended')
    drive_base.stop()
    attachment_motor.stop()
    drive_base.use_gyro(False)


# The main program starts here.
# XBox Controller Test

# Use to drive a robot around to get distances and angles. Helps reduce the time necessary to program distances in robot for competitions like FLL.

# Based on a concept by  FTC team 23247, the Monongahela Cryptid Cooperative) and Julian Huss. https://github.com/MonongahelaCryptidCooperative/FLL-Block-2024-2025/
xbox_controller_test()
