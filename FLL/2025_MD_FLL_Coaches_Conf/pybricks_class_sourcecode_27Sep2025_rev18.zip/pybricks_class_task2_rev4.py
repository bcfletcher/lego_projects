# Pybricks Class Task 2
import  pybricks_class_library_rev4 as RobotLib

async def pybricks_class_task2():
    # Pybricks Class Block Coding Task2
    print("Running Pybricks Class Task 2")
    await RobotLib.initializeRobotForTask() 

    RobotLib.driveBase.use_gyro(True)
    RobotLib.driveBase.settings(straight_speed=400,straight_acceleration=950)
    print('Move forward then move attachment down')
    await RobotLib.driveBase.straight(250)
    await RobotLib.rightAttachment.run_angle(2000, -210, RobotLib.Stop.COAST)
    await RobotLib.wait(1000)
    print('Move backward while moving the attachment up')
    await RobotLib.multitask(
        RobotLib.driveBase.straight(-250),
        RobotLib.rightAttachment.run_angle(150, 210)
    )
    print('Stop moving robot')
    RobotLib.driveBase.use_gyro(False)

#run_task(pybricks_class_task2())
