# Pybricks Class Menu
# menu revision number
menu_revision="5"
#
# import necessary libraries and functions
from pybricks_class_library_rev4 import *

print("Robot Menu, rev#",menu_revision)
print("Load Task 1")
from pybricks_class_task1_rev4 import pybricks_class_task1
print("Load Task 2")
from pybricks_class_task2_rev4 import pybricks_class_task2
print("Load Task 3")
from pybricks_class_task3_rev4 import pybricks_class_task3
print("Load Task 4")
from pybricks_class_task4_rev1 import pybricks_class_task4

print("Initialize Robot")
run_task(initiatizeRobot())

print("Running Hub Menu")
while True:
    selected = hub_menu("M","1","2","3","4","X")
    try:
        if selected == "M":
            # does nothing. used to show menu is active
            break
        elif selected == "1":
            print("Task 1 Selected")
            wait(1000)
            run_task(pybricks_class_task1())
            run_task(stopEverything())
        elif selected == "2":
            print("Task 2 Selected")
            wait(1000)
            run_task(pybricks_class_task2())
            run_task(stopEverything())
        elif selected == "3":
            print("Task 3 Selected")
            wait(1000)
            run_task(pybricks_class_task3())
            run_task(stopEverything())
        elif selected == "4":
            print("Task 4 - Robot Library Demo Selected")
            wait(1000)
            run_task(pybricks_class_task4())
            run_task(stopEverything())
        elif selected == "X":
            print("End of Menu")
            break
    except BaseException as menuException:
        print("Stop was Pressed or a Critical Error Occurred.")
        print(menuException)
        break
