# Pybricks Class Task 1
import  pybricks_class_library_rev4 as RobotLib

def pybricks_class_task1():

   # Pybricks Class Block Coding Task1

   print("Running Pybricks Class Task 1")
   await RobotLib.initializeRobotForTask() 

   print('Configure Robot')
   RobotLib.driveBase.use_gyro(True)
   RobotLib.driveBase.settings(straight_speed=200)
   RobotLib.driveBase.settings(straight_acceleration=900)
   RobotLib.driveBase.settings(turn_rate=600)
   print('Move the robot forward, move attachment, move back, and turn')
   await RobotLib.driveBase.straight(300)
   await RobotLib.rightAttachment.run_angle(900, -190)
   RobotLib.wait(1500)
   await RobotLib.rightAttachment.run_angle(900, 190)
   await RobotLib.driveBase.straight(-150)
   await RobotLib.driveBase.turn(90)
   await RobotLib.driveBase.straight(200)
   print('Stop moving robot')
   RobotLib.driveBase.use_gyro(False)

#run_task(pybricks_class_task1())

