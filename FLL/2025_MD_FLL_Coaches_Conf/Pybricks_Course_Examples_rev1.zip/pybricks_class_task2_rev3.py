# Pybricks Class Task 2
from pybricks_class_small_lib_rev3 import *
async def pybricks_class_task2():
    # Pybricks Class Block Coding Task2
    print("Running Pybricks Class Task 2")
    drive_base.use_gyro(True)
    drive_base.settings(straight_speed=400,straight_acceleration=950)
    print('Move forward then move attachment down')
    await drive_base.straight(250)
    await attachment_motor.run_angle(2000, -210, Stop.COAST)
    await wait(1000)
    print('Move backward while moving the attachment up')
    await multitask(
        drive_base.straight(-250),
        attachment_motor.run_angle(150, 210)
    )
    print('Stop moving robot')
    drive_base.use_gyro(False)

#run_task(pybricks_class_task2())
