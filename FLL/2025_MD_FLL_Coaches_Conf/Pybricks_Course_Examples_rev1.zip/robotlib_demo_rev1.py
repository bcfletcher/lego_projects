# Box Robot Demonstration
#
# task revision number
t1_revision="1"
#
from robot_library_rev29 import *

async def box_robot_task1():    
    print ("Box Robot Demonstration, Task 1 rev=",t1_revision)
    await initializeRobotForTask() 
    
    await wait(2000)
    if debugL1: print("  get and place coral tree")
    await driveRobot(285,750,500)
    await driveRobotAndLift(160,100,100,"left",1750,1000,False,True)
    await turnRobot(5,100,100)
    await driveRobotAndLift(-230,300,150,"left",1100,1000,False,True)
    await turnRobotAndLift(25,200,100,"left",1850,1000,False,True)

    if debugL1: print("   smash coral nursery")
    await driveRobot(580,850,500)
    await turnRobot(-15,200,200)
    await moveAttachment("right",-165,1000,False,True)
    await moveAttachment("right",0,1000,False,True)
    await driveRobot(-105,400,100)
    await turnRobot(76,200,200)

    if debugL1: print("   lift mast")
    await driveRobotAndLift(-80,100,100,"right",-170,300,False,True)
    # drive slowly to light mast
    await turnRobot(5,100,100)
    await driveRobot(260,200,400)
    # drive away from ship and lift robot arm out of the way
    await driveRobot(-210,400,1000)
    await moveAttachment("right",0,100,False,True)
    await driveRobot(100,400,1000)

    if debugL1: print("   goto shark")
    await turnRobot(-142,200,200)
    await driveRobot(300,700,500)

    if debugL1: print("   move away from shark")
    await driveRobot(-75,500,100)

    if debugL1: print("   pickup scuba diver")
    await turnRobot(-34,100,100)

    if debugL1: print("   pickup scuba diver")
    await driveRobot(-20,600,500)
    await driveRobotAndLift(80,100,100,"left",1100,950,False,True)
    await moveAttachment("left",1850,900,False,True)
    await driveRobot(-70,600,500)
    await turnRobot(45,300,300)
    await driveRobot(-175,500,500)

    await stopEverything()
    print("Task 1 - Completed")


# Runs the main program from start to finish.
# uncomment this line, if you want to run the task without main menu
#run_task(box_robot_task1())
