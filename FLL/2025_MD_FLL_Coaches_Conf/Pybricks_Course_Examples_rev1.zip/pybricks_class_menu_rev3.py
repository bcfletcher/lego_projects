# Pybricks Class Menu
# menu revision number
menu_revision="3"
#
# import necessary libraries and functions
from pybricks_class_small_lib_rev3 import *

print("Robot Menu, rev#",menu_revision)
print("Load Task1")
from pybricks_class_task1_rev3 import pybricks_class_task1
print("Load Task2")
from pybricks_class_task2_rev3 import pybricks_class_task2
print("Load Task3")
from pybricks_class_task3_rev3 import pybricks_class_task3

print("Running Hub Menu")
while True:
    selected = hub_menu("M","1","2","3","X")
    try:
        if selected == "M":
            # does nothing. used to show menu is active
            break
        if selected == "1":
            print("Task 1 Selected")
            wait(1000)
            run_task(pybricks_class_task1())
        elif selected == "2":
            print("Task 2 Selected")
            wait(1000)
            run_task(pybricks_class_task2())
        elif selected == "3":
            print("Task 3 Selected")
            wait(1000)
            run_task(pybricks_class_task3())
        elif selected == "X":
            # does nothing used to show end of menu
            break
    except BaseException as menuException:
        print("Stop was Pressed or a Critical Error Occurred.")
        print(menuException)
        break
