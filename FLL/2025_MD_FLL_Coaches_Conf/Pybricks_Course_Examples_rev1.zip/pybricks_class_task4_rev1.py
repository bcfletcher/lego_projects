# Pybricks Class Task4
task4_rev="1"
from pybricks_class_library_rev2 import *

async def pybricks_class_task4():

    initializeRobotForTask()

    await driveRobot(300,900,900)
    await wait(100)
    await driveRobot(-300,900,900)
