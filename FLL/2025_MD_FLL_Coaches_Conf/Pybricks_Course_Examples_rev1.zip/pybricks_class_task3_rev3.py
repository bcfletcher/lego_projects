# Pybricks Class Task 3
from pybricks_class_small_lib_rev3 import *
async def pybricks_class_task3():
    # Pybricks Class Block Coding Task3
    print("Running Pybricks Class Task 3")
    distance_to_move = 400
    drive_base.settings(straight_speed=200, straight_acceleration=600)
    print('Drive Forward by', distance_to_move, 'mm')
    await drive_base.straight(distance_to_move, then=Stop.BRAKE)
    distance_to_move = -350
    print('Drive Backward by', distance_to_move, 'mm')
    await drive_base.straight(distance_to_move, then=Stop.BRAKE)
    print('Stop and move attachment')
    attachment_motor.control.limits(speed=950,acceleration=950)
    print('Stop Robot')
    drive_base.use_gyro(False)

#run_task(pybricks_class_task3())
