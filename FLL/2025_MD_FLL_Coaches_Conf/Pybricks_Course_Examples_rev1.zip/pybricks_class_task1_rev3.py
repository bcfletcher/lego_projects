# Pybricks Class Task 1
from pybricks_class_small_lib_rev3 import *
def pybricks_class_task1():
   # Pybricks Class Block Coding Task1
   print("Running Pybricks Class Task 1")
   print('Configure Robot')
   drive_base.use_gyro(True)
   drive_base.settings(straight_speed=200)
   drive_base.settings(straight_acceleration=900)
   drive_base.settings(turn_rate=600)
   print('Move the robot forward, move attachment, move back, and turn')
   drive_base.straight(300)
   attachment_motor.run_angle(900, -190)
   wait(1500)
   attachment_motor.run_angle(900, 190)
   drive_base.straight(-150)
   drive_base.turn(90)
   drive_base.straight(200)
   print('Stop moving robot')
   drive_base.use_gyro(False)

#run_task(pybricks_class_task1())

